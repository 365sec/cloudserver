const plugin_version = '2019-0122-1200'
const plugin_name    = 'offical'

'use strict'
var plugin  = new RASP('offical')

// 检测逻辑总开关
// 
// block  -> 拦截
// log    -> 打印日志，不拦截
// ignore -> 关闭这个算法

var event_id = {
	sql:					1000,
	struts2_cmd:			1001,
	java_deserialization: 	1002,
	command_exec:			1003,
	file_upload:			1004,
	info_disclosure:		1005,
	fileread:				1006,
	discovery_known_webshell:	1007,
	discovery_unknown_webshell:	1008,
	ssrf_injection:				1009,
	directory_traversal:		1010,
	file_include:				1011,
	xxe_injection:				1012,
	xxs_injection:				1013,
	sensitive_file_download:	1014,
	protocal_attack:			1015,
	code_execute:				1016,
};

var threat_level = {
	urgent:   0,
	high:     1,
	middle:   2,
	commonly: 3,
};

var httpProtectConfig = {
	sqli_rx:{
		action: 'block',
		name: '算法1 - 规则匹配检测SQL注入攻击'
	},
	sqli_token:{
		action: 'block',
		name: '算法2 - 词法分析方式检测SQL注入攻击'
	},
	xss_rx:{
		action:'block',
		name: '算法1 - 规则匹配检测XSS攻击'
	},
	xss_token:{
		action:'block',
		name: '算法2 - 词法分析方式检测XSS攻击'
	},
	local_file_include:{
		action: 'block',
		name: '算法1 - 规则匹配检测本地文件包含'
	},
	remote_file_include:{
		action:'block',
		name:'算法1 - 规则匹配检测远程文件包含'
	},
	protocal_attack:{
		action:'block',
		name:'算法1 - 禁用PUT、DELETE等HTTP方法'
	},
	crlf_input:{
		action:'block',
		name:'算法1 - 规则分析相应拆分攻击'
	},
	php_code_execute:{
		action:'block',
		name:'算法1 - PHP代码注入攻击'
	},
	java_code_execute:{
		action:'block',
		name:'算法2 - Java代码注入攻击'
	},
	command_execute:{
		action:'block',
		name:'算法1 - 远程命令执行攻击'
	}
	
};

var algorithmConfig = {
    // SQL注入算法#1 - 匹配用户输入
    sqli_userinput: {
        action: 'block'
    },
    // SQL注入算法#1 - 是否拦截数据库管理器，默认关闭，有需要可改为 block
    sqli_dbmanager: {
        action: 'ignore'
    },
    // SQL注入算法#2 - 语句规范
    sqli_policy: {
        action:  'block',
        feature: {
            // 是否禁止多语句执行，select ...; update ...;
            'stacked_query':      true,

            // 是否禁止16进制字符串，select 0x41424344
            'no_hex':             true,

            // 禁止版本号注释，select/*!500001,2,*/3
            'version_comment':    true,

            // 函数黑名单，具体列表见下方，select load_file(...)
            'function_blacklist': true,

            // 拦截 union select NULL,NULL 或者 union select 1,2,3,4
            'union_null':         true,

            // 是否禁止常量比较，AND 8333=8555
            // 当代码编写不规范，常量比较算法会造成大量误报，所以默认不再开启此功能
            'constant_compare':   false,
        },
        function_blacklist: {
            // 文件操作
            'load_file':        true,

            // 时间差注入
            'benchmark':        true,
            'sleep':            true,
            'pg_sleep':         true,

            // 探测阶段
            'is_srvrolemember': true,

            // 报错注入
            'updatexml':        true,
            'extractvalue':     true,

            // 盲注函数，如有误报可删掉一些函数
            'hex':              true,
            'char':             true,
            'chr':              true, 
            'mid':              true,
            'ord':              true,
            'ascii':            true,                
            'bin':              true
        }
    },
    // SSRF - 来自用户输入，且为内网地址就拦截
    ssrf_userinput: {
        action: 'block'
    },
    // SSRF - 是否允许访问 aws metadata
    ssrf_aws: {
        action: 'block'
    },
    // SSRF - 是否允许访问 dnslog 地址
    ssrf_common: {
        action:  'block',
        domains: [
            '.ceye.io',
            '.vcap.me',
            '.xip.name',
            '.xip.io',
            '.nip.io',
            '.burpcollaborator.net'
        ]
    },
    // SSRF - 是否允许访问混淆后的IP地址
    ssrf_obfuscate: {
        action: 'block'
    },

    // 任意文件下载防护 - 来自用户输入
    readFile_userinput: {
        action: 'block'
    },
    // 任意文件下载防护 - 使用 ../../ 跳出 web 目录读取敏感文件
    readFile_traversal: {
        action: 'block'
    }, 
    // 任意文件下载防护 - 读取敏感文件，最后一道防线
    readFile_unwanted: {
        action: 'block'
    },

    // 写文件操作 - NTFS 流
    writeFile_NTFS: {
        action: 'block'
    },
    // 写文件操作 - PUT 上传脚本文件
    writeFile_PUT_script: {
        action: 'block'
    },    
    // 写文件操作 - 脚本文件
    // https://rasp.baidu.com/doc/dev/official.html#case-3
    writeFile_script: {
        action: 'log'
    },

    // 重命名和复制操作监控
    // v0.40 之后支持，暂时不开启
    // rename_webshell: {
    //     action: 'block'
    // },    
    // copy_webshell: {
    //     action: 'block'
    // },    

    // 文件管理器 - 反射方式列目录
    directory_reflect: {
        action: 'block'
    },
    // 文件管理器 - 查看敏感目录
    directory_unwanted: {
        action: 'block'
    },
    // 文件管理器 - 列出webroot之外的目录
    directory_outsideWebroot: {
        action: 'block'
    },

    // 文件包含 - 包含 http:// 内容
    include_http: {
        action: 'block'
    },
    // 文件包含 - 包含目录
    include_dir: {
        action: 'block'
    },
    // 文件包含 - 包含敏感文件
    include_unwanted: {
        action: 'block'
    },  
    // 文件包含 - 包含web目录之外的文件
    include_outsideWebroot: {
        action: 'block'
    },

    // XXE - 使用 gopher/ftp/dict/.. 等不常见协议访问外部实体
    xxe_protocol: {
        action: 'block'
    },

    // 文件上传 - COPY/MOVE 方式，仅适合 tomcat
    fileUpload_webdav: {
        action: 'block'
    },
    // 文件上传 - Multipart 表单方式
    fileUpload_multipart: {
        action: 'block'
    },

    // OGNL 代码执行漏洞
    ognl_exec: {
        action: 'block'
    },

    // 命令执行 - 反射，或者 eval 方式
    command_reflect: {
        action: 'block'
    },
    // 命令执行 - 常规方式，如有需求请改为 'ignore'
    command_other: {
        action: 'block'
    },

    // transformer 反序列化攻击
    transformer_deser: {
        action: 'block'
    }
}



// OpenRASP 大部分算法都不依赖规则，我们主要使用调用堆栈、编码规范、用户输入匹配的思路来检测漏洞。
// 
// 目前，只有文件访问 - 算法#4 加了一个探针，作为最后一道防线
// 当应用读取了这些文件，通常意味着服务器已经被入侵
// 这些配置是通用的，一般不需要定制

const clean = {
    action:     'ignore',
    message:    '无风险',
    confidence: 0
}

var forcefulBrowsing = {
    dotFiles: /\.(7z|tar|gz|bz2|xz|rar|zip|sql|db|sqlite)$/,
    nonUserDirectory: /^\/(proc|sys|root)/,

    // webdav 文件探针 - 最常被下载的文件
    unwantedFilenames: [
        // user files
        '.DS_Store',
        'id_rsa', 'id_rsa.pub', 'known_hosts', 'authorized_keys', 
        '.bash_history', '.csh_history', '.zsh_history', '.mysql_history',

        // project files
        '.htaccess', '.user.ini',

        'web.config', 'web.xml', 'build.property.xml', 'bower.json',
        'Gemfile', 'Gemfile.lock',
        '.gitignore',
        'error_log', 'error.log', 'nohup.out',
    ],

    // 目录探针 - webshell 查看频次最高的目录
    unwantedDirectory: [
        '/',
        '/home',
        '/var/log',
        '/private/var/log',
        '/proc',
        '/sys',
        'C:\\',
        'D:\\',
        'E:\\'
    ],

    // 文件探针 - webshell 查看频次最高的文件
    absolutePaths: [
        '/etc/shadow',
        '/etc/passwd',
        '/etc/hosts',
        '/etc/apache2/apache2.conf',
        '/root/.bash_history',
        '/root/.bash_profile',
        'c:\\windows\\system32\\inetsrv\\metabase.xml',
        'c:\\windows\\system32\\drivers\\etc\\hosts'
    ]
}

// 如果你配置了非常规的扩展名映射，比如让 .abc 当做PHP脚本执行，那你可能需要增加更多扩展名
var scriptFileRegex = /\.(aspx?|jspx?|php[345]?|phtml)\.?$/i

// 其他的 stream 都没啥用
var ntfsRegex       = /::\$(DATA|INDEX)$/i

// 常用函数

String.prototype.replaceAll = function(token, tokenValue) {
    var index  = 0;
    var string = this;
    
    do {
        string = string.replace(token, tokenValue);
    } while((index = string.indexOf(token, index + 1)) > -1);

    return string
}

function canonicalPath (path) {
    return path.replaceAll('/./', '/').replaceAll('//', '/').replaceAll('//', '/')
}

function basename (path) {
    var idx = path.lastIndexOf('/')
    return path.substr(idx + 1)
}

function validate_stack_php(stacks) {
    var verdict = false

    for (var i = 0; i < stacks.length; i ++) {
        var stack = stacks[i]

        // 来自 eval/assert/create_function/...
        if (stack.indexOf('eval()\'d code') != -1 
            || stack.indexOf('runtime-created function') != -1
            || stack.indexOf('assert code@') != -1
            || stack.indexOf('@call_user_func') != -1
            || stack.indexOf('regexp code@') != -1) {
            verdict = true
            break
        }
    }

    return verdict
}

function is_absolute_path(path, os) {

    // Windows - C:\\windows
    if (os == 'Windows') {
            
        if (path[1] == ':')
        {
            var drive = path[0].toLowerCase()
            if (drive >= 'a' && drive <= 'z')
            {
                return true
            }
        }        
    }
    
    // Unices - /root/
    return path[0] === '/'
}

function is_outside_webroot(appBasePath, realpath, path) {
    var verdict = false

    if (realpath.indexOf(appBasePath) == -1 && (path.indexOf('/../') !== -1 || path.indexOf('\\..\\') !== -1)) {
        verdict = true
    }

    return verdict
}

function is_from_userinput(parameter, target) {
    var verdict = false

    Object.keys(parameter).some(function (key) {
        var value = parameter[key]

        // 只处理非数组、hash情况
        if (value[0] == target) {
            verdict = true
            return true
        }
    })

    return verdict
}

// 开始

//if (RASP.get_jsengine() != 'v8') {
    // 在java语言下面，为了提高性能，SQLi/SSRF检测逻辑改为java实现
    // 所以，我们需要把一部分配置传递给java
//    RASP.config_set('algorithm.config', JSON.stringify(algorithmConfig))
//} else {
    // 对于PHP + V8，性能还不错，我们保留JS检测逻辑

    plugin.register('sql', function (params, context) {
		
        var reason     = false
        var parameters = context.parameter || {}
        var tokens     = RASP.sql_tokenize(params.query, params.server)

        // 算法1: 匹配用户输入
        // 1. 简单识别逻辑是否发生改变
        // 2. 识别数据库管理器   
        if (algorithmConfig.sqli_userinput.action != 'ignore') {
            Object.keys(parameters).some(function (name) {
                // 覆盖两种情况，后者仅PHP支持
                // 
                // ?id=XXXX
                // ?filter[category_id]=XXXX
                var value_list
				
                if (typeof parameters[name][0] == 'string') {
                    value_list = parameters[name]
                } else {
                    value_list = Object.values(parameters[name][0])
                }

                for (var i = 0; i < value_list.length; i ++) {
                    var value = value_list[i]

                    // 请求参数长度超过15才考虑，任何跨表查询都至少需要20个字符，其实可以写的更大点
                    // SELECT * FROM admin
                    // and updatexml(....)

                    if (value.length <= 10) {
                        continue
                    }
					
                    // sql查询和post参数一致 可认为在利用webshell进行数据库查询
                    if (value.length == params.query.length && value == params.query) {
                        // 是否拦截数据库管理器，有需要请改为 1
                        if (algorithmConfig.sqli_dbmanager.action != 'ignore') {
                            //reason = '算法2: WebShell - 拦截数据库管理器 - 攻击参数: ' + name
							reason = '正在利用webshell进行数据库操作, 攻击参数: ' + name + ' 理由: sql语句和post提交数据长度一致，疑似以被上传webshell后门。'
                            return true
                        } else {
                            continue
                        }
                    }

                    // 简单识别用户输入
					if (params.query.indexOf(value) == -1) {
                        continue
                    }
                    // 去掉用户输入再次匹配
                    var tokens2 = RASP.sql_tokenize(params.query.replaceAll(value, ''), params.server)

                    if (tokens.length - tokens2.length > 2) {
                        //reason = '算法1: 数据库查询逻辑发生改变 - 攻击参数: ' + name
						reason = '正在利用SQL注入进行攻击, 攻击参数: ' + name + ' 理由: 参数中存在sql关键词使数据库查询逻辑发生改变。'
                        return true
                    }
                }
            })
            if (reason !== false) {
                return {
					'event_id':	  event_id.sql,
                    'action':     algorithmConfig.sqli_userinput.action,
                    'confidence': 90,
                    'message':    reason,
					'threat_level':	threat_level.urgent
                }
            }
        }

        // 算法2: SQL语句策略检查（模拟SQL防火墙功能）
        if (algorithmConfig.sqli_policy.action != 'ignore') {
            var features  = algorithmConfig.sqli_policy.feature
            var func_list = algorithmConfig.sqli_policy.function_blacklist

            var tokens_lc = tokens.map(v => v.toLowerCase())

            for (var i = 1; i < tokens_lc.length; i ++) 
            {
                if (features['union_null'] && tokens_lc[i] === 'select') 
                {
                    var null_count = 0

                    // 寻找连续的逗号、NULL或者数字
                    for (var j = i + 1; j < tokens_lc.length && j < i + 6; j ++) {
                        if (tokens_lc[j] === ',' || tokens_lc[j] == 'null' || ! isNaN(parseInt(tokens_lc[j]))) {
                            null_count ++
                        } else {
                            break
                        }
                    }

                    // NULL,NULL,NULL == 5个token
                    // 1,2,3          == 5个token
                    if (null_count >= 5) {
                        reason = 'UNION-NULL 方式注入 - 字段类型探测'
                        break
                    }
                    continue
                }

                if (features['stacked_query'] && tokens_lc[i] == ';' && i != tokens_lc.length - 1) 
                {
                    reason = '禁止多语句查询'
                    break
                } 
                else if (features['no_hex'] && tokens_lc[i][0] === '0' && tokens_lc[i][1] === 'x') 
                {
                    reason = '禁止16进制字符串'
                    break
                } 
                else if (features['version_comment'] && tokens_lc[i][0] === '/' && tokens_lc[i][1] === '*' && tokens_lc[i][2] === '!') 
                {
                    reason = '禁止MySQL版本号注释'
                    break
                } 
                else if (features['constant_compare'] &&
                    i > 0 && i < tokens_lc.length - 1 && 
                    (tokens_lc[i] === 'xor'
                        || tokens_lc[i][0] === '<'
                        || tokens_lc[i][0] === '>' 
                        || tokens_lc[i][0] === '=')) 
                {
                    // @FIXME: 可绕过，暂时不更新
                    // 简单识别 NUMBER (>|<|>=|<=|xor) NUMBER
                    //          i-1         i          i+2    
                        
                    var op1  = tokens_lc[i - 1]
                    var op2  = tokens_lc[i + 1]

                    // @TODO: strip quotes
                    var num1 = parseInt(op1)
                    var num2 = parseInt(op2)

                    if (! isNaN(num1) && ! isNaN(num2)) {
                        // 允许 1=1, 2=0, 201801010=0 这样的常量对比以避免误报，只要有一个小于10就先忽略掉
                        // 
                        // SQLmap 是随机4位数字，不受影响
                        if (tokens_lc[i][0] === '=' && (num1 < 10 || num2 < 10))
                        {
                            continue;
                        }

                        reason = '禁止常量比较操作: ' + num1 + ' vs ' + num2
                        break
                    }                    
                } 
                else if (features['function_blacklist'] && i > 0 && tokens_lc[i][0] === '(') 
                {
                    // @FIXME: 可绕过，暂时不更新
                    if (func_list[tokens_lc[i - 1]]) {
                        reason = '禁止执行敏感函数: ' + tokens_lc[i - 1]
                        break
                    }
                }
            }

            if (reason !== false) {
                return {
					event_id:	  event_id.sql,
                    action:     algorithmConfig.sqli_policy.action,
                    message:    '正在利用SQL注入进行攻击, 数据库语句存在异常. 理由' + reason,
                    confidence: 100,
					threat_level:	threat_level.urgent
                }
            }
        }

        return clean
    })

    plugin.register('ssrf', function (params, context) {
        var hostname = params.hostname
        var url      = params.url
        var ip       = params.ip

        var reason   = false
        var action   = 'ignore'

        // 算法1 - ssrf_userinput
        // 当参数来自用户输入，且为内网IP，判定为SSRF攻击
        if (algorithmConfig.ssrf_userinput.action != 'ignore') 
        {
            if (ip.length &&
                is_from_userinput(context.parameter, url) &&
                /^(192|172|10)\./.test(ip[0]))
            {
                return {
					event_id: event_id.ssrf_injection,
					threat_level:	threat_level.urgent,
                    action:    algorithmConfig.ssrf_userinput.action,
                    message:   '正在进行SSRF攻击, 理由: 访问内网地址: ' + ip[0],
                    confidence: 100
                }
            }
        }

        // 算法2 - ssrf_common
        // 检查常见探测域名
        if (algorithmConfig.ssrf_common.action != 'ignore')
        {
            var blocked = false
            var domains = algorithmConfig.ssrf_common.domains

            if (hostname == 'requestb.in' || hostname == 'transfer.sh')
            {
                blocked = true
            }
            else
            {
                for (var i = 0; i < domains.length; i ++)
                {
                    if (hostname.endsWith(domains[i]))
                    {
                        blocked = true
                        break
                    }
                }
            }

            if (blocked)
            {
                return {
					event_id: event_id.ssrf_injection,
					threat_level:	threat_level.urgent,
                    action:    algorithmConfig.ssrf_common.action,
                    message:   '正在进行SSRF攻击, 理由: 访问已知的内网探测域名',
                    confidence: 100
                }                
            }
        } 

        // 算法3 - ssrf_aws
        // 检测AWS私有地址，如有需求可注释掉
        // 
        // TODO: 增加 Google Cloud 对应的私有地址
        if (algorithmConfig.ssrf_aws.action != 'ignore') 
        {
            if (hostname == '169.254.169.254') 
            {
                return {
					event_id: event_id.ssrf_injection,
					threat_level:	threat_level.urgent,
                    action:    algorithmConfig.ssrf_aws.action,
                    message:   '正在进行SSRF攻击, 理由: 读取 AWS metadata',
                    confidence: 100
                }                
            }
        }

        // 算法4 - ssrf_obfuscate
        // 
        // 检查混淆: 
        // http://2130706433
        // http://0x7f001
        // 
        // 以下混淆方式没有检测，容易误报
        // http://0x7f.0x0.0x0.0x1
        // http://0x7f.0.0.0    
        if (algorithmConfig.ssrf_obfuscate.action != 'ignore') 
        {
            var reason = false

            if (Number.isInteger(hostname))
            {
                reason = '尝试使用纯数字IP'
            }
            else if (hostname.startsWith('0x') && hostname.indexOf('.') === -1) 
            {
                reason = '尝试使用16进制IP'
            }

            if (reason)
            {
                return {
					event_id: event_id.ssrf_injection,
					threat_level:	threat_level.urgent,
                    action:    algorithmConfig.ssrf_obfuscate.action,
                    message:   '正在进行SSRF攻击, 理由: ' + reason,
                    confidence: 100
                }                
            }
        }

        return clean
    })

//}

// 主要用于识别webshell里的文件管理器
// 通常程序不会主动列目录或者查看敏感目录，e.g /home /etc /var/log 等等
// 
// 若有特例可调整
// 可结合业务定制: e.g 不能超出应用根目录
plugin.register('directory', function (params, context) {
    var path        = params.path
    var realpath    = params.realpath
    var appBasePath = context.appBasePath
    var server      = context.server

    // 算法1 - 读取敏感目录
    if (algorithmConfig.directory_unwanted.action != 'ignore') 
    {
        for (var i = 0; i < forcefulBrowsing.unwantedDirectory.length; i ++) {
            if (realpath == forcefulBrowsing.unwantedDirectory[i]) {
                return {
					event_id: event_id.discovery_known_webshell,
					threat_level:	threat_level.urgent,
                    action:     algorithmConfig.directory_unwanted.action,
                    message:    '正在利用WebShell文件管理器读取敏感目录',
                    confidence: 100
                }
            }
        }
    }

    // 算法2 - 使用至少2个/../，且跳出web目录
    if (algorithmConfig.directory_outsideWebroot.action != 'ignore') 
    {
        if (canonicalPath(path).indexOf('/../../') != -1 && realpath.indexOf(appBasePath) == -1) 
        {
            return {
				event_id: event_id.directory_traversal,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.directory_outsideWebroot.action,
                message:    '正在进行目录遍历攻击, 理由: 尝试列出Web目录以外的目录',
                confidence: 90
            }
        }
    }

    if (algorithmConfig.directory_reflect.action != 'ignore') 
    {

        // 目前，只有 PHP 支持通过堆栈方式，拦截列目录功能
        if (server.language == 'php' && validate_stack_php(params.stack)) 
        {
            return {
				event_id: event_id.discovery_known_webshell,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.directory_reflect.action,
                message:    '正在利用webshell进行目录操作, 存在Webshell，或者其他eval类型的后门',
                confidence: 90
            }            
        }
    }

    return clean
})


plugin.register('readFile', function (params, context) {
    var server = context.server

    //
    //【近期调整】
    // 算法1: 和URL比较，检查是否为成功的目录扫描。仅适用于 java webdav 方式 
    // 
    // 注意: 此方法受到 readfile.extension.regex 和资源文件大小的限制
    // https://rasp.baidu.com/doc/setup/others.html#java-common
    // 
    if (1 && server.language == 'java') {
        var filename_1 = basename(context.url)
        var filename_2 = basename(params.realpath)

        if (filename_1 == filename_2) {
            var matched = false

            // 尝试下载压缩包、SQL文件等等
            if (forcefulBrowsing.dotFiles.test(filename_1)) {
                matched = true
            } else {
                // 尝试访问敏感文件
                for (var i = 0; i < forcefulBrowsing.unwantedFilenames; i ++) {
                    if (forcefulBrowsing.unwantedFilenames[i] == filename_1) {
                        matched = true
                    }
                }
            }

            if (matched) {
                plugin.log('尝试下载敏感文件 (' + context.method.toUpperCase() + ' 方式): ' + params.realpath)
				return {
					event_id: event_id.fileread,
					threat_level:	threat_level.high,
                    action:     'log',
                    message:    '正在下载敏感文件 (' + context.method.toUpperCase() + ' 方式): ' + params.realpath,
					
                    // 如果是HEAD方式下载敏感文件，100% 扫描器攻击
                    confidence: context.method == 'head' ? 100 : 90
                }
            }
        }
    }

    //
    // 算法2: 文件、目录探针
    // 如果应用读取了列表里的文件，比如 /root/.bash_history，这通常意味着后门操作
    // 
    if (algorithmConfig.readFile_unwanted.action != 'ignore')
    {
        var realpath_lc = params.realpath.toLowerCase()

        for (var j = 0; j < forcefulBrowsing.absolutePaths.length; j ++) {
            if (forcefulBrowsing.absolutePaths[j] == realpath_lc) {
                return {
					event_id: event_id.discovery_known_webshell,
					threat_level:	threat_level.urgent,
                    action:     algorithmConfig.readFile_unwanted.action,
                    message:    '正在利用WebShell/文件管理器读取系统文件: ' + params.realpath,
                    confidence: 90
                }
            }
        }
    }

    //
    // 算法3: 检查文件遍历，看是否超出web目录范围
    // e.g 使用 ../../../etc/passwd 跨目录读取文件
    // 
    if (algorithmConfig.readFile_traversal.action != 'ignore') 
    {
        var path        = params.path
        var appBasePath = context.appBasePath

        if (is_outside_webroot(appBasePath, params.realpath, path)) {
            return {
				event_id: event_id.directory_traversal,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.readFile_traversal.action,
                message:    '正在进行目录遍历攻击，跳出web目录范围 (' + appBasePath + ')',
                confidence: 90
            }
        }
    }

    //
    // 算法4: 拦截任意文件下载漏洞，要读取的文件来自用户输入，且没有路径拼接
    //
    // 不影响正常操作，e.g
    // ?path=download/1.jpg
    // 
    if (algorithmConfig.readFile_userinput.action != 'ignore')
    {
        if (is_from_userinput(context.parameter, params.path))
        {
            // 1. 使用绝对路径
            // ?file=/etc/./hosts
            if (is_absolute_path(params.path, context.server.os))
            {
                return {
					event_id: event_id.fileread,
					threat_level:	threat_level.urgent,
                    action:     algorithmConfig.readFile_userinput.action,
                    message:    '正在进行任意文件下载攻击（绝对路径），目标文件: ' + params.realpath,
                    confidence: 90
                }   
            }

            // 2. 相对路径且包含 /../ 
            // ?file=download/../../etc/passwd
            if (params.path.indexOf('/../') !== -1 || params.path.indexOf('\\..\\') !== -1)
            {
                return {
					event_id: event_id.fileread,
					threat_level:	threat_level.urgent,
                    action:     algorithmConfig.readFile_userinput.action,
                    message:    '正在进行任意文件下载攻击（相对路径），目标文件: ' + params.realpath,
                    confidence: 90
                }                   
            }
        }
    }

    return clean
})

plugin.register('include', function (params, context) {
    var url = params.url    

    // 如果没有协议
    // ?file=../../../../../var/log/httpd/error.log
    if (url.indexOf('://') == -1) {
        var path        = canonicalPath(url)
        var realpath    = params.realpath
        var appBasePath = context.appBasePath

        // 是否跳出 web 目录？
        if (algorithmConfig.include_outsideWebroot.action != 'ignore' &&
            is_outside_webroot(appBasePath, realpath, path)) 
        {
            return {
				event_id: event_id.file_include,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.include_outsideWebroot.action,
                message:    '正在进行任意文件包含攻击，包含web目录范围之外的文件 (' + appBasePath + ')',
                confidence: 100
            }
        }

        return clean
    }

    // 如果有协议
    // include ('http://xxxxx')
    var items = url.split('://')

    // http 方式 SSRF/RFI
    if (items[0].toLowerCase() == 'http') 
    {
        if (algorithmConfig.include_http.action != 'ignore')
        {
            return {
				event_id: event_id.ssrf_injection,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.include_http.action,
                message:    '正在进行SSRF攻击 存在SSRF漏洞: ' + params.function + ' 方式',
                confidence: 70
            }  
        }        
    }

    // file 协议
    if (items[0].toLowerCase() == 'file') {
        var basename = items[1].split('/').pop()

        // 是否为目录？
        if (items[1].endsWith('/')) {
            // 部分应用，如果直接包含目录，会把这个目录内容列出来
            if (algorithmConfig.include_dir.action != 'ignore') {
                return {
					event_id: event_id.sensitive_file_download,
					threat_level:	threat_level.urgent,
                    action:     algorithmConfig.include_dir.action,
                    message:    '正在进行敏感目录访问: ' + params.function + ' 方式',
                    confidence: 100
                }
            }
        }

        // 是否为敏感文件？
        if (algorithmConfig.include_unwanted.action != 'ignore') {
            for (var i = 0; i < forcefulBrowsing.unwantedFilenames.length; i ++) {
                if (basename == forcefulBrowsing.unwantedFilenames[i]) {
                    return {
						event_id: event_id.sensitive_file_download,
						threat_level:	threat_level.urgent,
                        action:     algorithmConfig.include_unwanted.action,
                        message:    '正在进行敏感文件下载: ' + params.function + ' 方式',
                        confidence: 100
                    }
                }
            }
        }
    }

    return clean
})


plugin.register('writeFile', function (params, context) {

    // 写 NTFS 流文件，肯定不正常
    if (algorithmConfig.writeFile_NTFS.action != 'ignore') 
    {
        if (ntfsRegex.test(params.realpath)) {
            return {
				event_id: event_id.file_upload,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.writeFile_NTFS.action,
                message:    '正在尝试利用NTFS流上传后门: ' + params.realpath,
                confidence: 90
            }
        }
    }

    // PUT 上传
    if (context.method == 'put' &&
        algorithmConfig.writeFile_PUT_script.action != 'ignore') 
    {
        if (scriptFileRegex.test(params.realpath)) {
            return {
				event_id: event_id.file_upload,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.writeFile_PUT_script.action,
                message:    '正在使用 PUT 方式上传脚本文件，路径: ' + params.realpath,
                confidence: 90
            }
        }        
    }

    // 关于这个算法，请参考这个插件定制文档
    // https://rasp.baidu.com/doc/dev/official.html#case-3    
    if (algorithmConfig.writeFile_script.action != 'ignore') 
    {
        if (scriptFileRegex.test(params.realpath)) {
            return {
				event_id: event_id.file_upload,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.writeFile_script.action,
                message:    '正在尝试写入脚本文件，路径: ' + params.realpath,
                confidence: 90
            }
        }
    }
    return clean
})


if (algorithmConfig.fileUpload_multipart.action != 'ignore') 
{
    plugin.register('fileUpload', function (params, context) {

        if (scriptFileRegex.test(params.filename) || ntfsRegex.test(params.filename)) {
            return {
				event_id: event_id.file_upload,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.fileUpload_multipart.action,
                message:    '正在尝试上传脚本文件: ' + params.filename,
                confidence: 90
            }
        }

        if (params.filename == ".htaccess" || params.filename == ".user.ini") {
            return {
				event_id: event_id.file_upload,
				threat_level:	threat_level.urgent,
                action:     algorithmConfig.fileUpload_multipart.action,
                message:    '正在尝试上传 Apache/PHP 配置文件: ' + params.filename,
                confidence: 90
            } 
        }

        return clean
    })
}


if (algorithmConfig.fileUpload_webdav.action != 'ignore')
{
    plugin.register('webdav', function (params, context) {
        
        // 源文件不是脚本 && 目标文件是脚本，判定为MOVE方式写后门
        if (! scriptFileRegex.test(params.source) && scriptFileRegex.test(params.dest)) 
        {
            return {
				event_id: event_id.file_upload,
				threat_level:	threat_level.urgent,
                action:    algorithmConfig.fileUpload_webdav.action,
                message:   '正在尝试通过 ' + context.method + ' 方式上传脚本文件: ' + params.dest,
                confidence: 100
            }
        }

        return clean
    })
}


// if (0 && algorithmConfig.rename_webshell.action != 'ignore')
// {
//     plugin.register('rename', function (params, context) {
        
//         // 源文件不是脚本，且目标文件是脚本，判定为重命名方式写后门
//         // 案例有 ueditor getshell
//         if (! scriptFileRegex.test(params.source) && scriptFileRegex.test(params.dest)) 
//         {
//             return {
//                 action:    algorithmConfig.rename_webshell.action,
//                 message:   '重命名方式获取 webshell，源文件: ' + params.source,
//                 confidence: 100
//             }
//         }

//         return clean
//     })
// }


plugin.register('command', function (params, context) {
    var server  = context.server
    var message = undefined

    // 算法1: 根据堆栈，检查是否为反序列化攻击。
    // 理论上，此算法不存在误报

    if (algorithmConfig.command_reflect.action != 'ignore') {
        // Java 检测逻辑
        if (server.language == 'java') {
            var userCode = false
            var known    = {
                'java.lang.reflect.Method.invoke':                                              '尝试通过反射执行命令',
                'ognl.OgnlRuntime.invokeMethod':                                                '尝试通过 OGNL 代码执行命令',
                'com.thoughtworks.xstream.XStream.unmarshal':                                   '尝试通过 xstream 反序列化执行命令',
                'org.apache.commons.collections4.functors.InvokerTransformer.transform':        '尝试通过 transformer 反序列化执行命令',
                'org.jolokia.jsr160.Jsr160RequestDispatcher.dispatchRequest':                   '尝试通过 JNDI 注入方式执行命令',
                'com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze':     '尝试通过 fastjson 反序列化方式执行命令',
                'org.springframework.expression.spel.support.ReflectiveMethodExecutor.execute': '尝试通过 Spring SpEL 表达式执行命令'
            }
            
            for (var i = 2; i < params.stack.length; i ++) {
                var method = params.stack[i]

                if (method.startsWith('ysoserial.Pwner')) {
                    message = '正在使用YsoSerial漏洞利用工具进行反序列化攻击'
                    break
                }

                if (method == 'org.codehaus.groovy.runtime.ProcessGroovyMethods.execute') {
                    message = '正在尝试通过 Groovy 脚本执行命令'
                    break
                }

                // 仅当命令本身来自反射调用才拦截
                // 如果某个类是反射调用，这个类再主动执行命令，则忽略
                if (! method.startsWith('java.') && ! method.startsWith('sun.') && !method.startsWith('com.sun.')) {
                    userCode = true
                }

                if (known[method]) {
                    // 同上，如果反射调用和命令执行之间，包含用户代码，则不认为是反射调用
                    if (userCode && method == 'java.lang.reflect.Method.invoke') {
                        continue
                    }

                    message = known[method]
                    // break
                }
            }
        }

        // PHP 检测逻辑
        else if (server.language == 'php' && validate_stack_php(params.stack)) 
        {
            message = '正在利用Webshell或者基于 eval/assert/create_function/preg_replace/.. 等类型的代码执行漏洞进行攻击'
        }

        if (message) 
        {
            return {
				event_id: event_id.command_exec,
                action:     algorithmConfig.command_reflect.action,
                message:    message,
                confidence: 100,
				threat_level:	threat_level.urgent
            }
        }
    }

    // 算法2: 默认禁止命令执行
    // 如有需要可改成 log 或者 ignore
    // 或者根据URL来决定是否允许执行命令

    // 从 v0.31 开始，当命令执行来自非HTTP请求的，我们也会检测反序列化攻击
    // 但是不应该拦截正常的命令执行，所以这里加一个 context.url 检查
    if (! context.url) {
        return clean
    }

    if (algorithmConfig.command_other.action == 'ignore') {
        return clean
    } else {
        return {
			event_id: event_id.command_exec,
            action:     algorithmConfig.command_other.action,
            message:    '正在进行远程命令执行攻击',
            confidence: 90,
			threat_level:	threat_level.urgent
        } 
    }

})


// 注意: PHP 不支持XXE检测
plugin.register('xxe', function (params, context) {
    var items = params.entity.split('://')

    if (items.length >= 2) {
        var protocol = items[0]
        var address  = items[1]

        if (algorithmConfig.xxe_protocol.action != 'ignore') {
            if (protocol === 'gopher' || protocol === 'ftp' || protocol === 'dict' || protocol === 'expect') {
                return {
					event_id: event_id.xxe_injection,
                    action:     algorithmConfig.xxe_protocol.action,
                    message:    '正在进行SSRF/Blind XXE 攻击 (' + protocol + ' 协议)',
                    confidence: 100,
					threat_level:	threat_level.urgent
                }
            }
        }

        // file 协议 + 绝对路径, e.g
        // file:///etc/passwd
        //
        // 相对路径容易误报, e.g
        // file://xwork.dtd
        if (address.length > 0 && protocol === 'file' && address[0] == '/') {
            return {
				event_id: event_id.xxe_injection,
                action:     'log',
                message:    '正在读取外部实体 (file 协议)',
                confidence: 90,
				threat_level:	threat_level.high
            }
        }
    }
    return clean
})

if (algorithmConfig.ognl_exec.action != 'ignore') 
{
    // 默认情况下，当OGNL表达式长度超过30才会进入检测点，此长度可配置
    plugin.register('ognl', function (params, context) {
        // 常见 struts payload 语句特征
        var ognlPayloads = [
            'ognl.OgnlContext',
            'ognl.TypeConverter',
            'ognl.MemberAccess',
            '_memberAccess',
            'ognl.ClassResolver',
            'java.lang.Runtime',
            'java.lang.Class',
            'java.lang.ClassLoader',
            'java.lang.System',
            'java.lang.ProcessBuilder',
            'java.lang.Object', 
            'java.lang.Shutdown',
            'java.io.File',
            'javax.script.ScriptEngineManager',
            'com.opensymphony.xwork2.ActionContext'
        ]

        var ognlExpression = params.expression
        for (var index in ognlPayloads) 
        {
            if (ognlExpression.indexOf(ognlPayloads[index]) > -1) 
            {
                return {
					event_id: event_id.struts2_cmd,
                    action:     algorithmConfig.ognl_exec.action,
                    message:    '正在利用ognl表达式执行远程命令',
                    confidence: 100,
					threat_level:	threat_level.urgent
                }
            }

        }
        return clean
    })
}


// [[ 近期调整~ ]]
if (algorithmConfig.transformer_deser.action != 'ignore') {
    plugin.register('deserialization', function (params, context) {
        var deserializationInvalidClazz = [
            'org.apache.commons.collections.functors.InvokerTransformer',
            'org.apache.commons.collections.functors.InstantiateTransformer',
            'org.apache.commons.collections4.functors.InvokerTransformer',
            'org.apache.commons.collections4.functors.InstantiateTransformer',
            'org.codehaus.groovy.runtime.ConvertedClosure',
            'org.codehaus.groovy.runtime.MethodClosure',
            'org.springframework.beans.factory.ObjectFactory',
            'xalan.internal.xsltc.trax.TemplatesImpl'
        ]

        var clazz = params.clazz
        for (var index in deserializationInvalidClazz) {
            if (clazz === deserializationInvalidClazz[index]) {
                return {
					event_id: event_id.java_deserialization,
                    action:     algorithmConfig.transformer_deser.action,
                    message:    '正在进行反序列化攻击',
                    confidence: 100,
					threat_level:	threat_level.urgent
                }
            }
        }
        return clean
    })
}

plugin.register('request_body', function(params, context) {
	
    function detectXSS(params, context) {
        var xssRegex   = /<script|script>|<iframe|iframe>|javascript:(?!(?:history\.(?:go|back)|void\(0\)))/i
        var message    = '';
		var body = unescape(context.body);

		if (xssRegex.test(body)) {
			message = '正在进行跨站脚本攻击 请求内容: ' + body;
		}
        return message
    }
	
    // XSS 检测 DEMO //
    var message = detectXSS(params, context)

    if (message.length) {
        return {
			event_id: event_id.xxs_injection,
            action: 'block',
            message: message,
            confidence: 90,
			threat_level:	threat_level.middle
        }
    }
    return clean    
})


if(typeof get_sensor_type != 'undefined' && get_sensor_type() == 'waf'){
	
	

plugin.register('request', function(params, context) {
	
    function detectXSS(params, context) {
        var xssRegex   = /<script|script>|<iframe|iframe>|javascript:(?!(?:history\.(?:go|back)|void\(0\)))/i
        var message    = '';
		var querystring = unescape(context.querystring);

		if (xssRegex.test(querystring)) {
			message = '正在进行跨站脚本攻击 请求字符串: ' + querystring;
		}
        return message
    }

    // XSS 检测 DEMO //
    var message = detectXSS(params, context)

    if (message.length) {
        return {
			event_id: event_id.xxs_injection,
            action: 'block',
            message: message,
            confidence: 90,
			threat_level:	threat_level.middle
        }
    }
    return clean
})

function ab2str(buf) {
	return String.fromCharCode.apply(null, new Uint8Array(buf));
}

function matchVariables(value, operator){
	var result = {'detected':false};

	if(value == undefined || value == null)
		return result
	
	if('rx' in operator){
		for(var i = 0; i < operator.rx.length; i++){
			if(operator.rx[i].test(value)){
				result.detected = true;
				return result
			}
		}
	}

	if('pm' in operator){
		for(var i = 0; i < operator.pm.length; i++){
			if(value.toLowerCase().indexOf(operator.pm[i].toLowerCase()) >= 0){
				result.detected = true;
				return result
			}	
		}
	}
	
	if('detectSQL' in operator && operator.detectSQL){
		if(typeof detectSQL != "undefined"){
			var ret = detectSQL(value)
			if(ret.issql){
				result.detected = true;
				result.message = 'detected SQLi using libinjection with fingerprint ' + ret.fingerprint
				return result
			}
		}
	}
	
	if('detectXSS' in operator && operator.detectXSS){
		if(typeof detectXSS != "undefined"){
			var is_xss = detectXSS(value)
			if(is_xss){
				result.detected = true;
				result.message = 'detected XSS using libinjection.'
				return result
			}
		}
	}	
	return result
}

function detect(secrule, params, context, checkpoint, eventid) {
	var reason = false;
	var result = {}
	var match = {}
	
	!function(){
		if(secrule.variables.indexOf('ARGS_URL') >= 0){
			match = matchVariables(context.url, secrule.operator)
			if(match.detected){
				reason = '正在进行'+checkpoint+'攻击, URL为' + context.url
				console.log(reason)
				return result
			}
		}
		if(secrule.variables.indexOf('QUERY_STRING') >= 0){
			match = matchVariables(context.querystring, secrule.operator)
			if(match.detected){
				reason = '正在进行'+checkpoint+'攻击, QueryString为' + context.querystring
				console.log(reason)
				return result
			}
		}
		
		var parameters = context.parameter || {}
		for (var name in parameters)
		{
			try{
				var value_list
				
				if (typeof parameters[name] == 'string') {
					value_list = [parameters[name]]
				} else {
					value_list = Object.values(parameters[name])
				}
				
				if(secrule.variables.indexOf('ARGS_NAMES') >= 0){
					match = matchVariables(name, secrule.operator)
					if(match.detected){
						reason = '正在对参数名进行'+checkpoint+'攻击, 参数名为' + name
						console.log(reason)
						return result
					}
				}
			
				if(secrule.variables.indexOf('ARGS_VALUE') >= 0){
					for (var i = 0; i < value_list.length; i ++) {
						var value = value_list[i]
						
						if (value.length <= 2) {
							continue
						}
						
						match = matchVariables(value, secrule.operator)
						if(match.detected){
							reason = '正在对参数'+ name +'进行'+checkpoint+'攻击, 参数值为' + value
							console.log(reason)
							return result
						}
					}
				}
			}catch(e){
				console.log('exception:'+e.message)
			}
		}
		
		if ('Cookie' in context.header){
			var arr = context.header.Cookie.split('; ');
			for(var i = 0; i < arr.length; i++){
				var temp = arr[i].split('=');
				
				if(secrule.variables.indexOf('REQUEST_COOKIES_NAMES') >= 0){
					match = matchVariables(temp[0], secrule.operator)
					if(match.detected){
						reason = '正在对Cookie头'+ temp[0] +'进行'+checkpoint+'攻击'
						console.log(reason)
						return result
					}
				}
				
				if(secrule.variables.indexOf('REQUEST_COOKIES') >= 0){
					match = matchVariables(temp[1], secrule.operator)
					if(match.detected){
						reason = '正在对Cookie'+ temp[0] +'进行'+checkpoint+'攻击, 参数值为' + temp[1]
						console.log(reason)
						return result
					}
				}
			}
		}
			
		if(secrule.variables.indexOf('REQUEST_HEADERS') >= 0){
			
			for(var key in context.header){
				match = matchVariables(context.header[key], secrule.operator)
				if(match.detected){
					reason = '正在对请求头'+ key +'进行'+checkpoint+'攻击, 参数值为' + context.header[key]
					console.log(reason)
					return result
				}
			}
		}
		if(secrule.variables.indexOf('REQUEST_BODY') >= 0){
			var body = context.body
			if (body instanceof  ArrayBuffer){
				body = ab2str(context.body)
			}
			match = matchVariables(body, secrule.operator)
			if(match.detected){
				reason = '正在对请求体进行'+checkpoint+'攻击, 内容为' + body
				console.log(reason)
				return result
			}
		}
	}();

			
	if(reason !== false){
		if('message' in match){
			reason += ', '+ match.message
		}
		
		var ret = {
			event_id: eventid,
			action: secrule.action,
			message: reason,
			confidence: 90,
			threat_level: threat_level.high
		}
		return ret
	}
	
	return clean
}
	
plugin.register('request', function (params, context) {
	
	var secrule = {
		'action': httpProtectConfig.sqli_rx.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_COOKIES_NAMES',
			'REQUEST_COOKIES',
			'REQUEST_HEADERS',
			'REQUEST_BODY',
		],
		'operator' : {
			'rx':[
				/(?:(sleep\((\s*?)(\d*?)(\s*?)\)|benchmark\((.*?)\,(.*?)\)))/i,
				/(?:\b(?:m(?:s(?:ysaccessobjects|ysaces|ysobjects|ysqueries|ysrelationships|ysaccessstorage|ysaccessxml|ysmodules|ysmodules2|db)|aster\.\.sysdatabases|ysql\.db)\b|s(?:ys(?:\.database_name|aux)\b|chema(?:\W*\(|_name\b)|qlite(_temp)?_master\b)|d(?:atabas|b_nam)e\W*\(|information_schema\b|pg_(catalog|toast)\b|northwind\b|tempdb\b))/i,
				/(?:(?:(select|;)\s+(?:benchmark|if|sleep)\s*?\(\s*?\(?\s*?\w+))/i,
				/(?:(?:\s*?(?:exec|execute).*?(?:\W)xp_cmdshell)|(?:[\"'`]\s*?!\s*?[\"'`\w])|(?:from\W+information_schema\W)|(?:(?:(?:current_)?user|database|schema|connection_id)\s*?\([^\)]*?)|(?:[\"'`];?\s*?(?:select|union|having)\s*?[^\s])|(?:\wiif\s*?\()|(?:(?:exec|execute)\s+master\.)|(?:union select @)|(?:union[\w(\s]*?select)|(?:select.*?\w?user\()|(?:into[\s+]+(?:dump|out)file\s*?[\"'`]))/i,
				/(?:(?:^(-0000023456|4294967295|4294967296|2147483648|2147483647|0000012345|-2147483648|-2147483649|0000023456|3.0.00738585072007e-308|1e309)$))/i,
				/(?:(?:[\s()]case\s*?\()|(?:\)\s*?like\s*?\()|(?:having\s*?[^\s]+\s*?[^\w\s])|(?:if\s?\([\d\w]\s*?[=<>~]))/i,
				/(?:(?:alter\s*?\w+.*?(?:character|char)\s+set\s+\w+)|([\"'`];*?\s*?waitfor\s+(?:time|delay)\s+[\"'`])|(?:[\"'`];.*?:\s*?goto))/i,
				/(?:(?:merge.*?using\s*?\()|(execute\s*?immediate\s*?[\"'`])|(?:match\s*?[\w(),+-]+\s*?against\s*?\())/i,
				/(?:(?:(union(.*?)select(.*?)from)))/i,
				/(?:(?:select\s*?pg_sleep)|(?:waitfor\s*?delay\s?[\"'`]+\s?\d)|(?:;\s*?shutdown\s*?(?:;|--|#|\/\*|{)))/i,
				/(?:(?:\[\$(?:ne|eq|lte?|gte?|n?in|mod|all|size|exists|type|slice|x?or|div|like|between|and)\]))/i,
				/(?:(?:procedure\s+analyse\s*?\()|(?:;\s*?(declare|open)\s+[\w-]+)|(?:create\s+(procedure|function)\s*?\w+\s*?\(\s*?\)\s*?-)|(?:declare[^\w]+[@#]\s*?\w+)|(exec\s*?\(\s*?@))/i,
				/(?:(?:[\d\W]\s+as\s*?[\"'`\w]+\s*?from)|(?:^[\W\d]+\s*?(?:union|select|create|rename|truncate|load|alter|delete|update|insert|desc))|(?:(?:select|create|rename|truncate|load|alter|delete|update|insert|desc)\s+(?:(?:group_)concat|char|load_file)\s?\(?)|(?:end\s*?\);)|([\"'`]\s+regexp\W)|(?:[\s(]load_file\s*?\())/i
			],
			'pm':[]
		},
	}
	if(httpProtectConfig.sqli_rx.action != 'ignore'){
		return detect(secrule, params, context, 'SQL注入', event_id.sql)
	}
})

plugin.register('request', function (params, context) {
	
	var secrule = {
		'action': httpProtectConfig.sqli_token.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_COOKIES_NAMES',
			'REQUEST_COOKIES',
			'REQUEST_HEADERS',
			'REQUEST_BODY',
		],
		'operator' : {
			'detectSQL': true
		},
	}
	if(httpProtectConfig.sqli_token.action != 'ignore'){
		return detect(secrule, params, context, 'SQL注入', event_id.sql)
	}
})

plugin.register('request', function (params, context) {
	
	var secrule = {
		'action': httpProtectConfig.xss_rx.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'QUERY_STRING',
			'REQUEST_BODY',
		],
		'operator' : {
			'rx':[
				/(?:([<＜]script[^>＞]*[>＞][\s\S]*?))/i,
				/(?:([\s\"'`;\/0-9\=\x0B\x09\x0C\x3B\x2C\x28\x3B]+on\w+[\s\x0B\x09\x0C\x3B\x2C\x28\x3B]*?=))/i,
				/(?:[\s\S](?:x(?:link:href|html|mlns)|!ENTITY.*?SYSTEM|data:text\/html|pattern(?=.*?=)|formaction|\@import|base64)\b)/i,
				/(?:(?:<(?:(?:apple|objec)t|isindex|embed|style|form|meta)\b[^>]*?>[\s\S]*?|(?:=|U\s*?R\s*?L\s*?\()\s*?[^>]*?\s*?S\s*?C\s*?R\s*?I\s*?P\s*?T\s*?:))/i,
				/(?:\b(?:s(?:tyle|rc)|href)\b[\s\S]*?=)/i,
				/(?:<[^\w<>]*(?:[^<>\"'\s]*:)?[^\w<>]*(?:\W*?s\W*?c\W*?r\W*?i\W*?p\W*?t|\W*?f\W*?o\W*?r\W*?m|\W*?s\W*?t\W*?y\W*?l\W*?e|\W*?s\W*?v\W*?g|\W*?m\W*?a\W*?r\W*?q\W*?u\W*?e\W*?e|(?:\W*?l\W*?i\W*?n\W*?k|\W*?o\W*?b\W*?j\W*?e\W*?c\W*?t|\W*?e\W*?m\W*?b\W*?e\W*?d|\W*?a\W*?p\W*?p\W*?l\W*?e\W*?t|\W*?p\W*?a\W*?r\W*?a\W*?m|\W*?i?\W*?f\W*?r\W*?a\W*?m\W*?e|\W*?b\W*?a\W*?s\W*?e|\W*?b\W*?o\W*?d\W*?y|\W*?m\W*?e\W*?t\W*?a|\W*?i\W*?m\W*?a?\W*?g\W*?e?|\W*?v\W*?i\W*?d\W*?e\W*?o|\W*?a\W*?u\W*?d\W*?i\W*?o|\W*?b\W*?i\W*?n\W*?d\W*?i\W*?n\W*?g\W*?s|\W*?s\W*?e\W*?t|\W*?a\W*?n\W*?i\W*?m\W*?a\W*?t\W*?e)[^>\w])|(?:<\w[\s\S]*[\s\/]|['\"](?:[\s\S]*[\s\/])?)(?:formaction|style|background|src|lowsrc|ping|on(?:d(?:e(?:vice(?:(?:orienta|mo)tion|proximity|found|light)|livery(?:success|error)|activate)|r(?:ag(?:e(?:n(?:ter|d)|xit)|(?:gestur|leav)e|start|drop|over)?|op)|i(?:s(?:c(?:hargingtimechange|onnect(?:ing|ed))|abled)|aling)|ata(?:setc(?:omplete|hanged)|(?:availabl|chang)e|error)|urationchange|ownloading|blclick)|Moz(?:M(?:agnifyGesture(?:Update|Start)?|ouse(?:PixelScroll|Hittest))|S(?:wipeGesture(?:Update|Start|End)?|crolledAreaChanged)|(?:(?:Press)?TapGestur|BeforeResiz)e|EdgeUI(?:C(?:omplet|ancel)|Start)ed|RotateGesture(?:Update|Start)?|A(?:udioAvailable|fterPaint))|c(?:o(?:m(?:p(?:osition(?:update|start|end)|lete)|mand(?:update)?)|n(?:t(?:rolselect|extmenu)|nect(?:ing|ed))|py)|a(?:(?:llschang|ch)ed|nplay(?:through)?|rdstatechange)|h(?:(?:arging(?:time)?ch)?ange|ecking)|(?:fstate|ell)change|u(?:echange|t)|l(?:ick|ose))|m(?:o(?:z(?:pointerlock(?:change|error)|(?:orientation|time)change|fullscreen(?:change|error)|network(?:down|up)load)|use(?:(?:lea|mo)ve|o(?:ver|ut)|enter|wheel|down|up)|ve(?:start|end)?)|essage|ark)|s(?:t(?:a(?:t(?:uschanged|echange)|lled|rt)|k(?:sessione|comma)nd|op)|e(?:ek(?:complete|ing|ed)|(?:lec(?:tstar)?)?t|n(?:ding|t))|u(?:ccess|spend|bmit)|peech(?:start|end)|ound(?:start|end)|croll|how)|b(?:e(?:for(?:e(?:(?:scriptexecu|activa)te|u(?:nload|pdate)|p(?:aste|rint)|c(?:opy|ut)|editfocus)|deactivate)|gin(?:Event)?)|oun(?:dary|ce)|l(?:ocked|ur)|roadcast|usy)|a(?:n(?:imation(?:iteration|start|end)|tennastatechange)|fter(?:(?:scriptexecu|upda)te|print)|udio(?:process|start|end)|d(?:apteradded|dtrack)|ctivate|lerting|bort)|DOM(?:Node(?:Inserted(?:IntoDocument)?|Removed(?:FromDocument)?)|(?:CharacterData|Subtree)Modified|A(?:ttrModified|ctivate)|Focus(?:Out|In)|MouseScroll)|r(?:e(?:s(?:u(?:m(?:ing|e)|lt)|ize|et)|adystatechange|pea(?:tEven)?t|movetrack|trieving|ceived)|ow(?:s(?:inserted|delete)|e(?:nter|xit))|atechange)|p(?:op(?:up(?:hid(?:den|ing)|show(?:ing|n))|state)|a(?:ge(?:hide|show)|(?:st|us)e|int)|ro(?:pertychange|gress)|lay(?:ing)?)|t(?:ouch(?:(?:lea|mo)ve|en(?:ter|d)|cancel|start)|ime(?:update|out)|ransitionend|ext)|u(?:s(?:erproximity|sdreceived)|p(?:gradeneeded|dateready)|n(?:derflow|load))|f(?:o(?:rm(?:change|input)|cus(?:out|in)?)|i(?:lterchange|nish)|ailed)|l(?:o(?:ad(?:e(?:d(?:meta)?data|nd)|start)?|secapture)|evelchange|y)|g(?:amepad(?:(?:dis)?connected|button(?:down|up)|axismove)|et)|e(?:n(?:d(?:Event|ed)?|abled|ter)|rror(?:update)?|mptied|xit)|i(?:cc(?:cardlockerror|infochange)|n(?:coming|valid|put))|o(?:(?:(?:ff|n)lin|bsolet)e|verflow(?:changed)?|pen)|SVG(?:(?:Unl|L)oad|Resize|Scroll|Abort|Error|Zoom)|h(?:e(?:adphoneschange|l[dp])|ashchange|olding)|v(?:o(?:lum|ic)e|ersion)change|w(?:a(?:it|rn)ing|heel)|key(?:press|down|up)|(?:AppComman|Loa)d|no(?:update|match)|Request|zoom))[\s\x08]*?=)/i,
				/(?:(?:\W|^)(?:javascript:(?:[\s\S]+[=\\\(\[\.<]|[\s\S]*?(?:\bname\b|\\[ux]\d))|data:(?:(?:[a-z]\w+\/\w[\w+-]+\w)?[;,]|[\s\S]*?;[\s\S]*?\b(?:base64|charset=)|[\s\S]*?,[\s\S]*?<[\s\S]*?\w[\s\S]*?>))|@\W*?i\W*?m\W*?p\W*?o\W*?r\W*?t\W*?(?:\/\*[\s\S]*?)?(?:[\"']|\W*?u\W*?r\W*?l[\s\S]*?\()|\W*?-\W*?m\W*?o\W*?z\W*?-\W*?b\W*?i\W*?n\W*?d\W*?i\W*?n\W*?g[\s\S]*?:[\s\S]*?\W*?u\W*?r\W*?l[\s\S]*?\()/i,
				/(?:(document.cookie|document.write|parentnode|innerhtml|window.location))/i,
				/(?:<style.*?>.*?((@[i\\\\])|(([:=]|(&#x?0*((58)|(3A)|(61)|(3D));?)).*?([(\\\\]|(&#x?0*((40)|(28)|(92)|(5C));?)))))/i,
				/(?:<.*[:]?vmlframe.*?[\s/+]*?src[\s/+]*=)/i,
				/(?:(j|(&#x?0*((74)|(4A)|(106)|(6A));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(a|(&#x?0*((65)|(41)|(97)|(61));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(v|(&#x?0*((86)|(56)|(118)|(76));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(a|(&#x?0*((65)|(41)|(97)|(61));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(s|(&#x?0*((83)|(53)|(115)|(73));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(c|(&#x?0*((67)|(43)|(99)|(63));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(r|(&#x?0*((82)|(52)|(114)|(72));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(i|(&#x?0*((73)|(49)|(105)|(69));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(p|(&#x?0*((80)|(50)|(112)|(70));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(t|(&#x?0*((84)|(54)|(116)|(74));?))([\t]|(&((#x?0*(9|(13)|(10)|A|D);?)|(tab;)|(newline;))))*(:|(&((#x?0*((58)|(3A));?)|(colon;)))).)/i,
				/(?:<META[\s/+].*?http-equiv[\s/+]*=[\s/+]*[\"\'`]?(((c|(&#x?0*((67)|(43)|(99)|(63));?)))|((r|(&#x?0*((82)|(52)|(114)|(72));?)))|((s|(&#x?0*((83)|(53)|(115)|(73));?)))))/i,
				/(?:<META[\s/+].*?charset[\s/+]*=)/i
				],
			'pm':[]
		},
	}
	if(httpProtectConfig.xss_rx.action != 'ignore'){
		return detect(secrule, params, context, '跨站脚本', event_id.xxs_injection)
	}
})

plugin.register('request', function (params, context) {
	
	var secrule = {
		'action': httpProtectConfig.xss_token.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_BODY',
		],
		'operator' : {
			'detectXSS': true
		},
	}
	if(httpProtectConfig.xss_token.action != 'ignore'){
		return detect(secrule, params, context, '跨站脚本', event_id.xxs_injection)
	}
})

plugin.register('request', function (params, context) {
	var result = {}
	
	var lfi_secrule = [{
		'action': httpProtectConfig.local_file_include.action,
		'variables' : [
			'ARGS_URL',
			'REQUEST_HEADERS',
			'REQUEST_BODY'
		],
		'operator' : {
			//Encoded /../ Payloads
			//remote_file_include
			'rx':[
				/(?:\x5c|(?:%(?:c(?:0%(?:[2aq]f|5c|9v)|1%(?:[19p]c|8s|af))|2(?:5(?:c(?:0%25af|1%259c)|2f|5c)|%46|f)|(?:(?:f(?:8%8)?0%8|e)0%80%a|bg%q)f|%3(?:2(?:%(?:%6|4)6|F)|5%%63)|u(?:221[56]|002f|EFC8|F025)|1u|5c)|0x(?:2f|5c)|\/))(?:%(?:(?:f(?:(?:c%80|8)%8)?0%8|e)0%80%ae|2(?:(?:5(?:c0%25a|2))?e|%45)|u(?:(?:002|ff0)e|2024)|%32(?:%(?:%6|4)5|E)|c0(?:%[256aef]e|\.))|\.(?:%0[01]|\?)?|\?\.?|0x2e){2}(?:\x5c|(?:%(?:c(?:0%(?:[2aq]f|5c|9v)|1%(?:[19p]c|8s|af))|2(?:5(?:c(?:0%25af|1%259c)|2f|5c)|%46|f)|(?:(?:f(?:8%8)?0%8|e)0%80%a|bg%q)f|%3(?:2(?:%(?:%6|4)6|F)|5%%63)|u(?:221[56]|002f|EFC8|F025)|1u|5c)|0x(?:2f|5c)|\/))/i
				],
			'pm':['../', '..\\']// Decoded /../ Payloads
		},
	},
	{
		'action': httpProtectConfig.local_file_include.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE'
		],
		'operator' : {
			'rx':[
				],
			'pm':[
				// Apache
				// (no slash; also guards against old.htaccess, old.htpasswd, etc.)
				'.htaccess',
				'.htdigest',
				'.htpasswd',
				// Version control
				'/.git/',
				'/.gitignore',
				'/.hg/',
				'/.hgignore',
				'/.svn/',
				// Wordpress
				'wp-config.php',
				'wp-config.bak',
				'wp-config.old',
				'wp-config.temp',
				'wp-config.tmp',
				'wp-config.txt',
				// Symfony
				'/config/config.yml',
				'/config/config_dev.yml',
				'/config/config_prod.yml',
				'/config/config_test.yml',
				'/config/parameters.yml',
				'/config/routing.yml',
				'/config/security.yml',
				'/config/services.yml',
				// Drupal
				'/sites/default/default.settings.php',
				'/sites/default/settings.php',
				// Magento
				'/app/etc/local.xml',
				// Sublime Text
				'/sftp-config.json',
				// ASP.NET
				'/Web.config',
				// Node
				'/gruntfile.js',
				'/npm-debug.log',
				// Composer
				'/composer.json',
				'/composer.lock',
				'/packages.json',
				// dotenv
				'/.env',
				'/etc/passwd',
				'/var/log/apache',
				'var/log/nginx',
				'usr/local/logs',
				'proc/self/environ'
			]
		},
	}]
	
	if(httpProtectConfig.local_file_include.action != 'ignore'){
		for(var i = 0; i < lfi_secrule.length; i++){
			result = detect(lfi_secrule[i], params, context, '本地文件包含', event_id.file_include)
			if (result.action != 'ignore') 
				return result
		}
	}
	var rfi_secrule = [{
		'action': httpProtectConfig.remote_file_include.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
		],
		'operator' : {
			'rx':[
				/^(?:ht|f)tps?:\/\/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/i,
				/^(?:ft|htt)ps?(.*?)\?+$/i
				],
			'pm':[]
		},
	},
	{
		'action': httpProtectConfig.remote_file_include.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_BODY'
		],
		'operator' : {
			'rx':[
				/(?:(\binclude\s*\([^)]*|mosConfig_absolute_path|_CONF\[path\]|_SERVER\[DOCUMENT_ROOT\]|GALLERY_BASEDIR|path\[docroot\]|appserv_root|config\[root_dir\])=(ht|f)tps?:\/\/)/i
				],
			'pm':[]
		},
	}]
	if(httpProtectConfig.remote_file_include.action != 'ignore'){
		for(var i = 0; i < rfi_secrule.length; i++){
			result = detect(rfi_secrule[i], params, context, '远程文件包含', event_id.file_include)
			if (result.action != 'ignore') 
				return result
		}
	}

})

plugin.register('request', function (params, context) {
	var unallow_method = ['DELETE', 'PUT', 'MOVE']
	
	if(context.method == undefined || context.method == null)
		return clean
	
	if(httpProtectConfig.protocal_attack.action != 'ignore'){
		if(unallow_method.indexOf(context.method.toUpperCase()) >= 0){
			return {
				event_id: event_id.protocal_attack,
				action: httpProtectConfig.protocal_attack.action,
				message: '正在尝试使用HTTP '+ context.method +'方法.',
				confidence: 90,
				threat_level: 1
			}
		}		
	}

})

plugin.register('request', function (params, context) {
	var result = {}
	
	var csrf_secrule = [{
		'action': httpProtectConfig.crlf_input.action,
		'variables' : [
			'REQUEST_COOKIES_NAMES',
			'REQUEST_COOKIES'
		],
		'operator' : {
			'rx':[
				/[\r\n]\W*?(?:content-(type|length)|set-cookie|location):/i,
				/(?:\bhttp\/(?:0\.9|1\.[01])|<(?:html|meta)\b)/i
				],
			'pm':[]
		},
	},
	{
		'action': httpProtectConfig.crlf_input.action,
		'variables' : [
			'REQUEST_HEADERS'
		],
		'operator' : {
			'rx':[
				/(\n|\r)/i
				],
			'pm':[]
		},
	}
	]
	if(httpProtectConfig.crlf_input.action != 'ignore'){
		for(var i = 0; i < csrf_secrule.length; i++){
			result = detect(csrf_secrule[i], params, context, '响应拆分')
			if (result.action != 'ignore') 
				return result
		}	
	}
})


plugin.register('request', function (params, context) {
	var result = {}
	
	var php_secrule = [{
		'action': httpProtectConfig.php_code_execute.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_COOKIES_NAMES',
			'REQUEST_COOKIES',
		],
		'operator' : {
			'rx':[
				],
			'pm':[
				//php标签
				'<?', 
				'<?php', 
				'[php]', 
				'[\php]',
				//php变量
				'$GLOBALS',
				'$HTTP_COOKIE_VARS',
				'$HTTP_ENV_VARS',
				'$HTTP_GET_VARS',
				'$HTTP_POST_FILES',
				'$HTTP_POST_VARS',
				'$HTTP_RAW_POST_DATA',
				'$HTTP_REQUEST_VARS',
				'$HTTP_SERVER_VARS',
				'$_COOKIE',
				'$_ENV',
				'$_FILES',
				'$_GET',
				'$_POST',
				'$_REQUEST',
				'$_SERVER',
				'$_SESSION',
				'$argc',
				'$argv',
				//php函数
				'__halt_compiler',
				'apache_child_terminate',
				'base64_decode',
				'bzdecompress',
				'call_user_func',
				'call_user_func_array',
				'call_user_method',
				'call_user_method_array',
				'convert_uudecode',
				'file_get_contents',
				'file_put_contents',
				'fsockopen',
				'gzdecode',
				'gzinflate',
				'gzuncompress',
				'include_once',
				'invokeargs',
				'pcntl_exec',
				'pcntl_fork',
				'pfsockopen',
				'posix_getcwd',
				'posix_getpwuid',
				'posix_getuid',
				'posix_uname',
				'ReflectionFunction',
				'require_once',
				'shell_exec',
				'str_rot13',
				'sys_get_temp_dir',
				'wp_remote_fopen',
				'wp_remote_get',
				'wp_remote_head',
				'wp_remote_post',
				'wp_remote_request',
				'wp_safe_remote_get',
				'wp_safe_remote_head',
				'wp_safe_remote_post',
				'wp_safe_remote_request',
				'zlib_decode'
			]
		},
	}
	]
	if(httpProtectConfig.php_code_execute.action != 'ignore'){
		for(var i = 0; i < php_secrule.length; i++){
			result = detect(php_secrule[i], params, context, 'PHP代码执行', event_id.code_execute)
			if (result.action != 'ignore') 
				return result
		}		
	}	
})

plugin.register('request', function (params, context) {
	var result = {}
		
	var java_secrule = [{
		'action': httpProtectConfig.java_code_execute.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_COOKIES_NAMES',
			'REQUEST_COOKIES',
		],
		'operator' : {
			'rx':[
					/java\.lang\.(?:runtime|processbuilder)/i,
					/(?:runtime|processbuilder)/i,
					/(?:clonetransformer|forclosure|instantiatefactory|instantiatetransformer|invokertransformer|prototypeclonefactory|prototypeserializationfactory|whileclosure|getproperty|filewriter|xmldecoder)/i,
					/java\b.+(?:runtime|processbuilder)/i
				],
			'pm':[
				'com.opensymphony.xwork2',
				'com.sun.org.apache',
				'java.io.BufferedInputStream',
				'java.io.BufferedReader',
				'java.io.ByteArrayInputStream',
				'java.io.ByteArrayOutputStream',
				'java.io.CharArrayReader',
				'java.io.DataInputStream',
				'java.io.File',
				'java.io.FileOutputStream',
				'java.io.FilterInputStream',
				'java.io.FilterOutputStream',
				'java.io.FilterReader',
				'java.io.InputStream',
				'java.io.InputStreamReader',
				'java.io.LineNumberReader',
				'java.io.ObjectOutputStream',
				'java.io.OutputStream',
				'java.io.PipedOutputStream',
				'java.io.PipedReader',
				'java.io.PrintStream',
				'java.io.PushbackInputStream',
				'java.io.Reader',
				'java.io.StringReader',
				'java.lang.Class',
				'java.lang.Integer',
				'java.lang.Number',
				'java.lang.Object',
				'java.lang.Process',
				'java.lang.ProcessBuilder',
				'java.lang.reflect',
				'java.lang.Runtime',
				'java.lang.String',
				'java.lang.StringBuilder',
				'java.lang.System',
				'javax.script.ScriptEngineManager',
				'org.apache.commons',
				'org.apache.struts',
				'org.apache.struts2',
				'org.omg.CORBA'
			]
		},
	}
	]
	if(httpProtectConfig.java_code_execute.action != 'ignore'){
		for(var i = 0; i < java_secrule.length; i++){
			result = detect(java_secrule[i], params, context, 'Java代码执行', event_id.code_execute)
			if (result.action != 'ignore') 
				return result
		}		
	}

	
})

plugin.register('request', function (params, context) {
	var result = {}
		
	var rce_secrule = [{
		'action': httpProtectConfig.command_execute.action,
		'variables' : [
			'ARGS_NAMES',
			'ARGS_VALUE',
			'REQUEST_COOKIES_NAMES',
			'REQUEST_COOKIES',
		],
		'operator' : {
			'rx':[
					new RegExp("(?:;|\{|\||\|\||&|&&|\n|\r|`)\s*[\(,@\'\"\s]*(?:[\w'\"\./]+/|[\\\\'\"\^]*\w[\\\\'\"\^]*:.*\\\\|[\^\.\w '\"/\\\\]*\\\\)?[\"\^]*(?:m[\"\^]*(?:y[\"\^]*s[\"\^]*q[\"\^]*l(?:[\"\^]*(?:d[\"\^]*u[\"\^]*m[\"\^]*p(?:[\"\^]*s[\"\^]*l[\"\^]*o[\"\^]*w)?|h[\"\^]*o[\"\^]*t[\"\^]*c[\"\^]*o[\"\^]*p[\"\^]*y|a[\"\^]*d[\"\^]*m[\"\^]*i[\"\^]*n|s[\"\^]*h[\"\^]*o[\"\^]*w))?|s[\"\^]*(?:i[\"\^]*(?:n[\"\^]*f[\"\^]*o[\"\^]*3[\"\^]*2|e[\"\^]*x[\"\^]*e[\"\^]*c)|c[\"\^]*o[\"\^]*n[\"\^]*f[\"\^]*i[\"\^]*g|g[\"\^]*(?:[\s,;]|\.|/|<|>).*|t[\"\^]*s[\"\^]*c)|o[\"\^]*(?:u[\"\^]*n[\"\^]*t[\"\^]*(?:(?:[\s,;]|\.|/|<|>).*|v[\"\^]*o[\"\^]*l)|v[\"\^]*e[\"\^]*u[\"\^]*s[\"\^]*e[\"\^]*r|[dr][\"\^]*e[\"\^]*(?:[\s,;]|\.|/|<|>).*)|k[\"\^]*(?:d[\"\^]*i[\"\^]*r[\"\^]*(?:[\s,;]|\.|/|<|>).*|l[\"\^]*i[\"\^]*n[\"\^]*k)|d[\"\^]*(?:s[\"\^]*c[\"\^]*h[\"\^]*e[\"\^]*d|(?:[\s,;]|\.|/|<|>).*)|a[\"\^]*p[\"\^]*i[\"\^]*s[\"\^]*e[\"\^]*n[\"\^]*d|b[\"\^]*s[\"\^]*a[\"\^]*c[\"\^]*l[\"\^]*i|e[\"\^]*a[\"\^]*s[\"\^]*u[\"\^]*r[\"\^]*e|m[\"\^]*s[\"\^]*y[\"\^]*s)|d[\"\^]*(?:i[\"\^]*(?:s[\"\^]*k[\"\^]*(?:(?:m[\"\^]*g[\"\^]*m|p[\"\^]*a[\"\^]*r)[\"\^]*t|s[\"\^]*h[\"\^]*a[\"\^]*d[\"\^]*o[\"\^]*w)|r[\"\^]*(?:(?:[\s,;]|\.|/|<|>).*|u[\"\^]*s[\"\^]*e)|f[\"\^]*f[\"\^]*(?:[\s,;]|\.|/|<|>).*)|e[\"\^]*(?:l[\"\^]*(?:p[\"\^]*r[\"\^]*o[\"\^]*f|t[\"\^]*r[\"\^]*e[\"\^]*e|(?:[\s,;]|\.|/|<|>).*)|v[\"\^]*(?:m[\"\^]*g[\"\^]*m[\"\^]*t|c[\"\^]*o[\"\^]*n)|(?:f[\"\^]*r[\"\^]*a|b[\"\^]*u)[\"\^]*g)|s[\"\^]*(?:a[\"\^]*(?:c[\"\^]*l[\"\^]*s|d[\"\^]*d)|q[\"\^]*u[\"\^]*e[\"\^]*r[\"\^]*y|m[\"\^]*o[\"\^]*(?:v[\"\^]*e|d)|g[\"\^]*e[\"\^]*t|r[\"\^]*m)|(?:r[\"\^]*i[\"\^]*v[\"\^]*e[\"\^]*r[\"\^]*q[\"\^]*u[\"\^]*e[\"\^]*r|o[\"\^]*s[\"\^]*k[\"\^]*e)[\"\^]*y|(?:c[\"\^]*o[\"\^]*m[\"\^]*c[\"\^]*n[\"\^]*f|x[\"\^]*d[\"\^]*i[\"\^]*a)[\"\^]*g|a[\"\^]*t[\"\^]*e[\"\^]*(?:[\s,;]|\.|/|<|>).*|n[\"\^]*s[\"\^]*s[\"\^]*t[\"\^]*a[\"\^]*t)|c[\"\^]*(?:o[\"\^]*(?:m[\"\^]*(?:p[\"\^]*(?:(?:a[\"\^]*c[\"\^]*t[\"\^]*)?(?:[\s,;]|\.|/|<|>).*|m[\"\^]*g[\"\^]*m[\"\^]*t)|e[\"\^]*x[\"\^]*p)|n[\"\^]*(?:2[\"\^]*p|v[\"\^]*e)[\"\^]*r[\"\^]*t|p[\"\^]*y)|l[\"\^]*(?:e[\"\^]*a[\"\^]*(?:n[\"\^]*m[\"\^]*g[\"\^]*r|r[\"\^]*m[\"\^]*e[\"\^]*m)|u[\"\^]*s[\"\^]*t[\"\^]*e[\"\^]*r)|h[\"\^]*(?:k[\"\^]*(?:n[\"\^]*t[\"\^]*f[\"\^]*s|d[\"\^]*s[\"\^]*k)|d[\"\^]*i[\"\^]*r[\"\^]*(?:[\s,;]|\.|/|<|>).*)|s[\"\^]*(?:c[\"\^]*(?:r[\"\^]*i[\"\^]*p[\"\^]*t|c[\"\^]*m[\"\^]*d)|v[\"\^]*d[\"\^]*e)|e[\"\^]*r[\"\^]*t[\"\^]*(?:u[\"\^]*t[\"\^]*i[\"\^]*l|r[\"\^]*e[\"\^]*q)|a[\"\^]*(?:l[\"\^]*l[\"\^]*(?:[\s,;]|\.|/|<|>).*|c[\"\^]*l[\"\^]*s)|m[\"\^]*d(?:[\"\^]*k[\"\^]*e[\"\^]*y)?|i[\"\^]*p[\"\^]*h[\"\^]*e[\"\^]*r|u[\"\^]*r[\"\^]*l)|f[\"\^]*(?:o[\"\^]*r[\"\^]*(?:m[\"\^]*a[\"\^]*t[\"\^]*(?:[\s,;]|\.|/|<|>).*|f[\"\^]*i[\"\^]*l[\"\^]*e[\"\^]*s|e[\"\^]*a[\"\^]*c[\"\^]*h)|i[\"\^]*n[\"\^]*d[\"\^]*(?:(?:[\s,;]|\.|/|<|>).*|s[\"\^]*t[\"\^]*r)|s[\"\^]*(?:m[\"\^]*g[\"\^]*m[\"\^]*t|u[\"\^]*t[\"\^]*i[\"\^]*l)|t[\"\^]*(?:p[\"\^]*(?:[\s,;]|\.|/|<|>).*|y[\"\^]*p[\"\^]*e)|r[\"\^]*e[\"\^]*e[\"\^]*d[\"\^]*i[\"\^]*s[\"\^]*k|c[\"\^]*(?:[\s,;]|\.|/|<|>).*|g[\"\^]*r[\"\^]*e[\"\^]*p)|n[\"\^]*(?:e[\"\^]*t[\"\^]*(?:s[\"\^]*(?:t[\"\^]*a[\"\^]*t|v[\"\^]*c|h)|(?:[\s,;]|\.|/|<|>).*|c[\"\^]*a[\"\^]*t|d[\"\^]*o[\"\^]*m)|t[\"\^]*(?:b[\"\^]*a[\"\^]*c[\"\^]*k[\"\^]*u[\"\^]*p|r[\"\^]*i[\"\^]*g[\"\^]*h[\"\^]*t[\"\^]*s)|(?:s[\"\^]*l[\"\^]*o[\"\^]*o[\"\^]*k[\"\^]*u|m[\"\^]*a)[\"\^]*p|c[\"\^]*(?:(?:[\s,;]|\.|/|<|>).*|a[\"\^]*t)|b[\"\^]*t[\"\^]*s[\"\^]*t[\"\^]*a[\"\^]*t)|e[\"\^]*(?:x[\"\^]*(?:p[\"\^]*(?:a[\"\^]*n[\"\^]*d[\"\^]*(?:[\s,;]|\.|/|<|>).*|l[\"\^]*o[\"\^]*r[\"\^]*e[\"\^]*r)|i[\"\^]*t)|v[\"\^]*e[\"\^]*n[\"\^]*t[\"\^]*(?:c[\"\^]*r[\"\^]*e[\"\^]*a[\"\^]*t[\"\^]*e|v[\"\^]*w[\"\^]*r)|n[\"\^]*d[\"\^]*l[\"\^]*o[\"\^]*c[\"\^]*a[\"\^]*l|g[\"\^]*r[\"\^]*e[\"\^]*p|r[\"\^]*a[\"\^]*s[\"\^]*e|c[\"\^]*h[\"\^]*o)|g[\"\^]*(?:a[\"\^]*t[\"\^]*h[\"\^]*e[\"\^]*r[\"\^]*n[\"\^]*e[\"\^]*t[\"\^]*w[\"\^]*o[\"\^]*r[\"\^]*k[\"\^]*i[\"\^]*n[\"\^]*f[\"\^]*o|p[\"\^]*(?:(?:r[\"\^]*e[\"\^]*s[\"\^]*u[\"\^]*l|e[\"\^]*d[\"\^]*i)[\"\^]*t|u[\"\^]*p[\"\^]*d[\"\^]*a[\"\^]*t[\"\^]*e)|i[\"\^]*t[\"\^]*(?:[\s,;]|\.|/|<|>).*|e[\"\^]*t[\"\^]*m[\"\^]*a[\"\^]*c)|i[\"\^]*(?:r[\"\^]*b(?:[\"\^]*(?:1(?:[\"\^]*[89])?|2[\"\^]*[012]))?|f[\"\^]*m[\"\^]*e[\"\^]*m[\"\^]*b[\"\^]*e[\"\^]*r|p[\"\^]*c[\"\^]*o[\"\^]*n[\"\^]*f[\"\^]*i[\"\^]*g|n[\"\^]*e[\"\^]*t[\"\^]*c[\"\^]*p[\"\^]*l|c[\"\^]*a[\"\^]*c[\"\^]*l[\"\^]*s)|a[\"\^]*(?:d[\"\^]*(?:d[\"\^]*u[\"\^]*s[\"\^]*e[\"\^]*r[\"\^]*s|m[\"\^]*o[\"\^]*d[\"\^]*c[\"\^]*m[\"\^]*d)|r[\"\^]*p[\"\^]*(?:[\s,;]|\.|/|<|>).*|t[\"\^]*t[\"\^]*r[\"\^]*i[\"\^]*b|s[\"\^]*s[\"\^]*o[\"\^]*c|z[\"\^]*m[\"\^]*a[\"\^]*n)|l[\"\^]*(?:o[\"\^]*g[\"\^]*(?:e[\"\^]*v[\"\^]*e[\"\^]*n[\"\^]*t|t[\"\^]*i[\"\^]*m[\"\^]*e|m[\"\^]*a[\"\^]*n|o[\"\^]*f[\"\^]*f)|a[\"\^]*b[\"\^]*e[\"\^]*l[\"\^]*(?:[\s,;]|\.|/|<|>).*|u[\"\^]*s[\"\^]*r[\"\^]*m[\"\^]*g[\"\^]*r)|b[\"\^]*(?:(?:c[\"\^]*d[\"\^]*(?:b[\"\^]*o[\"\^]*o|e[\"\^]*d[\"\^]*i)|r[\"\^]*o[\"\^]*w[\"\^]*s[\"\^]*t[\"\^]*a)[\"\^]*t|i[\"\^]*t[\"\^]*s[\"\^]*a[\"\^]*d[\"\^]*m[\"\^]*i[\"\^]*n|o[\"\^]*o[\"\^]*t[\"\^]*c[\"\^]*f[\"\^]*g)|h[\"\^]*(?:o[\"\^]*s[\"\^]*t[\"\^]*n[\"\^]*a[\"\^]*m[\"\^]*e|d[\"\^]*w[\"\^]*w[\"\^]*i[\"\^]*z)|j[\"\^]*a[\"\^]*v[\"\^]*a[\"\^]*(?:[\s,;]|\.|/|<|>).*|7[\"\^]*z(?:[\"\^]*[ar])?)(?:\.[\"\^]*\w+)?\b"),
					new RegExp("(?:;|\{|\||\|\||&|&&|\n|\r|`)\s*[\(,@\'\"\s]*(?:[\w'\"\./]+/|[\\\\'\"\^]*\w[\\\\'\"\^]*:.*\\\\|[\^\.\w '\"/\\\\]*\\\\)?[\"\^]*(?:s[\"\^]*(?:y[\"\^]*s[\"\^]*(?:t[\"\^]*e[\"\^]*m[\"\^]*(?:p[\"\^]*r[\"\^]*o[\"\^]*p[\"\^]*e[\"\^]*r[\"\^]*t[\"\^]*i[\"\^]*e[\"\^]*s[\"\^]*(?:d[\"\^]*a[\"\^]*t[\"\^]*a[\"\^]*e[\"\^]*x[\"\^]*e[\"\^]*c[\"\^]*u[\"\^]*t[\"\^]*i[\"\^]*o[\"\^]*n[\"\^]*p[\"\^]*r[\"\^]*e[\"\^]*v[\"\^]*e[\"\^]*n[\"\^]*t[\"\^]*i[\"\^]*o[\"\^]*n|(?:p[\"\^]*e[\"\^]*r[\"\^]*f[\"\^]*o[\"\^]*r[\"\^]*m[\"\^]*a[\"\^]*n[\"\^]*c|h[\"\^]*a[\"\^]*r[\"\^]*d[\"\^]*w[\"\^]*a[\"\^]*r)[\"\^]*e|a[\"\^]*d[\"\^]*v[\"\^]*a[\"\^]*n[\"\^]*c[\"\^]*e[\"\^]*d)|i[\"\^]*n[\"\^]*f[\"\^]*o)|k[\"\^]*e[\"\^]*y|d[\"\^]*m)|h[\"\^]*(?:o[\"\^]*(?:w[\"\^]*(?:g[\"\^]*r[\"\^]*p|m[\"\^]*b[\"\^]*r)[\"\^]*s|r[\"\^]*t[\"\^]*c[\"\^]*u[\"\^]*t)|e[\"\^]*l[\"\^]*l[\"\^]*r[\"\^]*u[\"\^]*n[\"\^]*a[\"\^]*s|u[\"\^]*t[\"\^]*d[\"\^]*o[\"\^]*w[\"\^]*n|r[\"\^]*p[\"\^]*u[\"\^]*b[\"\^]*w|a[\"\^]*r[\"\^]*e|i[\"\^]*f[\"\^]*t)|e[\"\^]*(?:t[\"\^]*(?:(?:x[\"\^]*)?(?:[\s,;]|\.|/|<|>).*|l[\"\^]*o[\"\^]*c[\"\^]*a[\"\^]*l)|c[\"\^]*p[\"\^]*o[\"\^]*l|l[\"\^]*e[\"\^]*c[\"\^]*t)|c[\"\^]*(?:h[\"\^]*t[\"\^]*a[\"\^]*s[\"\^]*k[\"\^]*s|l[\"\^]*i[\"\^]*s[\"\^]*t)|u[\"\^]*b[\"\^]*(?:i[\"\^]*n[\"\^]*a[\"\^]*c[\"\^]*l|s[\"\^]*t)|t[\"\^]*a[\"\^]*r[\"\^]*t[\"\^]*(?:[\s,;]|\.|/|<|>).*|i[\"\^]*g[\"\^]*v[\"\^]*e[\"\^]*r[\"\^]*i[\"\^]*f|l[\"\^]*(?:e[\"\^]*e[\"\^]*p|m[\"\^]*g[\"\^]*r)|o[\"\^]*r[\"\^]*t|f[\"\^]*c|v[\"\^]*n)|p[\"\^]*(?:s[\"\^]*(?:s[\"\^]*(?:h[\"\^]*u[\"\^]*t[\"\^]*d[\"\^]*o[\"\^]*w[\"\^]*n|e[\"\^]*r[\"\^]*v[\"\^]*i[\"\^]*c[\"\^]*e|u[\"\^]*s[\"\^]*p[\"\^]*e[\"\^]*n[\"\^]*d)|l[\"\^]*(?:o[\"\^]*g[\"\^]*(?:g[\"\^]*e[\"\^]*d[\"\^]*o[\"\^]*n|l[\"\^]*i[\"\^]*s[\"\^]*t)|i[\"\^]*s[\"\^]*t)|p[\"\^]*(?:a[\"\^]*s[\"\^]*s[\"\^]*w[\"\^]*d|i[\"\^]*n[\"\^]*g)|g[\"\^]*e[\"\^]*t[\"\^]*s[\"\^]*i[\"\^]*d|e[\"\^]*x[\"\^]*e[\"\^]*c|f[\"\^]*i[\"\^]*l[\"\^]*e|i[\"\^]*n[\"\^]*f[\"\^]*o|k[\"\^]*i[\"\^]*l[\"\^]*l)|o[\"\^]*(?:w[\"\^]*e[\"\^]*r[\"\^]*(?:s[\"\^]*h[\"\^]*e[\"\^]*l[\"\^]*l(?:[\"\^]*_[\"\^]*i[\"\^]*s[\"\^]*e)?|c[\"\^]*f[\"\^]*g)|r[\"\^]*t[\"\^]*q[\"\^]*r[\"\^]*y|p[\"\^]*d)|r[\"\^]*(?:i[\"\^]*n[\"\^]*t[\"\^]*(?:(?:[\s,;]|\.|/|<|>).*|b[\"\^]*r[\"\^]*m)|n[\"\^]*(?:c[\"\^]*n[\"\^]*f[\"\^]*g|m[\"\^]*n[\"\^]*g[\"\^]*r)|o[\"\^]*m[\"\^]*p[\"\^]*t)|a[\"\^]*t[\"\^]*h[\"\^]*(?:p[\"\^]*i[\"\^]*n[\"\^]*g|(?:[\s,;]|\.|/|<|>).*)|e[\"\^]*r[\"\^]*(?:l(?:[\"\^]*(?:s[\"\^]*h|5))?|f[\"\^]*m[\"\^]*o[\"\^]*n)|y[\"\^]*t[\"\^]*h[\"\^]*o[\"\^]*n(?:[\"\^]*(?:3(?:[\"\^]*m)?|2))?|k[\"\^]*g[\"\^]*m[\"\^]*g[\"\^]*r|h[\"\^]*p(?:[\"\^]*[57])?|u[\"\^]*s[\"\^]*h[\"\^]*d|i[\"\^]*n[\"\^]*g)|r[\"\^]*(?:e[\"\^]*(?:(?:p[\"\^]*l[\"\^]*a[\"\^]*c[\"\^]*e|n(?:[\"\^]*a[\"\^]*m[\"\^]*e)?|s[\"\^]*e[\"\^]*t)[\"\^]*(?:[\s,;]|\.|/|<|>).*|g[\"\^]*(?:s[\"\^]*v[\"\^]*r[\"\^]*3[\"\^]*2|e[\"\^]*d[\"\^]*i[\"\^]*t|(?:[\s,;]|\.|/|<|>).*|i[\"\^]*n[\"\^]*i)|c[\"\^]*(?:d[\"\^]*i[\"\^]*s[\"\^]*c|o[\"\^]*v[\"\^]*e[\"\^]*r)|k[\"\^]*e[\"\^]*y[\"\^]*w[\"\^]*i[\"\^]*z)|u[\"\^]*(?:n[\"\^]*(?:d[\"\^]*l[\"\^]*l[\"\^]*3[\"\^]*2|a[\"\^]*s)|b[\"\^]*y[\"\^]*(?:1(?:[\"\^]*[89])?|2[\"\^]*[012]))|a[\"\^]*(?:s[\"\^]*(?:p[\"\^]*h[\"\^]*o[\"\^]*n[\"\^]*e|d[\"\^]*i[\"\^]*a[\"\^]*l)|r[\"\^]*(?:[\s,;]|\.|/|<|>).*)|m[\"\^]*(?:(?:d[\"\^]*i[\"\^]*r[\"\^]*)?(?:[\s,;]|\.|/|<|>).*|t[\"\^]*s[\"\^]*h[\"\^]*a[\"\^]*r[\"\^]*e)|o[\"\^]*(?:u[\"\^]*t[\"\^]*e[\"\^]*(?:[\s,;]|\.|/|<|>).*|b[\"\^]*o[\"\^]*c[\"\^]*o[\"\^]*p[\"\^]*y)|s[\"\^]*(?:t[\"\^]*r[\"\^]*u[\"\^]*i|y[\"\^]*n[\"\^]*c)|d[\"\^]*(?:[\s,;]|\.|/|<|>).*)|t[\"\^]*(?:a[\"\^]*(?:s[\"\^]*k[\"\^]*(?:k[\"\^]*i[\"\^]*l[\"\^]*l|l[\"\^]*i[\"\^]*s[\"\^]*t|s[\"\^]*c[\"\^]*h[\"\^]*d|m[\"\^]*g[\"\^]*r)|k[\"\^]*e[\"\^]*o[\"\^]*w[\"\^]*n)|(?:i[\"\^]*m[\"\^]*e[\"\^]*o[\"\^]*u|p[\"\^]*m[\"\^]*i[\"\^]*n[\"\^]*i|e[\"\^]*l[\"\^]*n[\"\^]*e|l[\"\^]*i[\"\^]*s)[\"\^]*t|s[\"\^]*(?:d[\"\^]*i[\"\^]*s[\"\^]*c[\"\^]*o|s[\"\^]*h[\"\^]*u[\"\^]*t[\"\^]*d)[\"\^]*n|y[\"\^]*p[\"\^]*e[\"\^]*(?:p[\"\^]*e[\"\^]*r[\"\^]*f|(?:[\s,;]|\.|/|<|>).*)|r[\"\^]*(?:a[\"\^]*c[\"\^]*e[\"\^]*r[\"\^]*t|e[\"\^]*e))|w[\"\^]*(?:i[\"\^]*n[\"\^]*(?:d[\"\^]*i[\"\^]*f[\"\^]*f|m[\"\^]*s[\"\^]*d[\"\^]*p|v[\"\^]*a[\"\^]*r|r[\"\^]*[ms])|u[\"\^]*(?:a[\"\^]*(?:u[\"\^]*c[\"\^]*l[\"\^]*t|p[\"\^]*p)|s[\"\^]*a)|s[\"\^]*c[\"\^]*(?:r[\"\^]*i[\"\^]*p[\"\^]*t|u[\"\^]*i)|e[\"\^]*v[\"\^]*t[\"\^]*u[\"\^]*t[\"\^]*i[\"\^]*l|m[\"\^]*i[\"\^]*(?:m[\"\^]*g[\"\^]*m[\"\^]*t|c)|a[\"\^]*i[\"\^]*t[\"\^]*f[\"\^]*o[\"\^]*r|h[\"\^]*o[\"\^]*a[\"\^]*m[\"\^]*i|g[\"\^]*e[\"\^]*t)|u[\"\^]*(?:s[\"\^]*(?:e[\"\^]*r[\"\^]*a[\"\^]*c[\"\^]*c[\"\^]*o[\"\^]*u[\"\^]*n[\"\^]*t[\"\^]*c[\"\^]*o[\"\^]*n[\"\^]*t[\"\^]*r[\"\^]*o[\"\^]*l[\"\^]*s[\"\^]*e[\"\^]*t[\"\^]*t[\"\^]*i[\"\^]*n[\"\^]*g[\"\^]*s|r[\"\^]*s[\"\^]*t[\"\^]*a[\"\^]*t)|n[\"\^]*(?:r[\"\^]*a[\"\^]*r|z[\"\^]*i[\"\^]*p))|q[\"\^]*(?:u[\"\^]*e[\"\^]*r[\"\^]*y[\"\^]*(?:[\s,;]|\.|/|<|>).*|p[\"\^]*r[\"\^]*o[\"\^]*c[\"\^]*e[\"\^]*s[\"\^]*s|w[\"\^]*i[\"\^]*n[\"\^]*s[\"\^]*t[\"\^]*a|g[\"\^]*r[\"\^]*e[\"\^]*p)|o[\"\^]*(?:d[\"\^]*b[\"\^]*c[\"\^]*(?:a[\"\^]*d[\"\^]*3[\"\^]*2|c[\"\^]*o[\"\^]*n[\"\^]*f)|p[\"\^]*e[\"\^]*n[\"\^]*f[\"\^]*i[\"\^]*l[\"\^]*e[\"\^]*s)|v[\"\^]*(?:o[\"\^]*l[\"\^]*(?:[\s,;]|\.|/|<|>).*|e[\"\^]*r[\"\^]*i[\"\^]*f[\"\^]*y)|x[\"\^]*c[\"\^]*(?:a[\"\^]*c[\"\^]*l[\"\^]*s|o[\"\^]*p[\"\^]*y)|z[\"\^]*i[\"\^]*p[\"\^]*(?:[\s,;]|\.|/|<|>).*)(?:\.[\"\^]*\w+)?\b")
				],
			'pm':[
			]
		},
	}
	]
	if(httpProtectConfig.command_execute.action != 'ignore'){
		for(var i = 0; i < rce_secrule.length; i++){
			result = detect(rce_secrule[i], params, context, '远程命令执行', event_id.command_exec)
			if (result.action != 'ignore') 
				return result
		}
	}
})
}

plugin.log('AppSensor plugin '+ plugin_name +' initialized, version: '+ plugin_version)
